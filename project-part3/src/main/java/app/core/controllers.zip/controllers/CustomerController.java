package app.core.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import app.core.auth.UserCredentials;
import app.core.entities.Category;
import app.core.entities.Coupon;
import app.core.entities.Customer;
import app.core.exception.CouponSystemException;
import app.core.services.CustomerServiceImpl;

@CrossOrigin
@RestController
@RequestMapping("/api/customer/")
public class CustomerController {// extends ClientController {

	@Autowired
	private CustomerServiceImpl customerService;

//	@PostMapping
//	@Override
//	public boolean login(@RequestParam UserCredentials userCredentials) throws CouponSystemException, LoginException {
//		return customerService.login(userCredentials);
//	}

	@PostMapping(headers = { HttpHeaders.AUTHORIZATION })
	public void purchaseCoupon(@RequestBody Coupon coupon, HttpServletRequest req) throws CouponSystemException {
		UserCredentials user = (UserCredentials) req.getAttribute("user");
		customerService.purchaseCoupon(coupon, user.getId());
	}

	@GetMapping(path = "coupons", headers = { HttpHeaders.AUTHORIZATION })
	public List<Coupon> getCustomerCoupons(HttpServletRequest req) throws CouponSystemException {
		UserCredentials user = (UserCredentials) req.getAttribute("user");
		return customerService.getCustomerCoupons(user.getId());
	}

	@GetMapping(path = "coupons-by-category", headers = { HttpHeaders.AUTHORIZATION })
	public List<Coupon> getCustomerCoupons(@RequestParam Category category, HttpServletRequest req)
			throws CouponSystemException {
		UserCredentials user = (UserCredentials) req.getAttribute("user");
		return customerService.getCustomerCoupons(category.name(), user.getId());
	}

	@GetMapping(path = "coupons-until-price", headers = { HttpHeaders.AUTHORIZATION })
	public List<Coupon> getCustomerCoupons(@RequestParam double maxPrice, HttpServletRequest req)
			throws CouponSystemException {
		UserCredentials user = (UserCredentials) req.getAttribute("user");
		return customerService.getCustomerCoupons(maxPrice, user.getId());
	}

	@GetMapping(path = "details", headers = { HttpHeaders.AUTHORIZATION })
	public Customer getCustomerDetails(HttpServletRequest req) throws CouponSystemException {
		UserCredentials user = (UserCredentials) req.getAttribute("user");
		return customerService.getCustomerDetails(user.getId());
	}

}
