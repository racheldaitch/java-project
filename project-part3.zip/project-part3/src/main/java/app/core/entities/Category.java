package app.core.entities;

public enum Category {

	FOOD, ELECTRICITY, RESTAURANT, VACATION;

}
